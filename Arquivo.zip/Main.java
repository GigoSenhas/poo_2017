
/**
 * Escreva a descrição da classe Main aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Main{
    
   private static Menu m = new Menu();
   
   public static void main(String[] argv){
       m.menu();
   }
}
